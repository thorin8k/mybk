-- Myeskuel Database Dump
-- version 1.01b
-- Developed: Anish Karim C
-- Credits: http://www.phpclasses.org

-- Class Page: http://www.phpclasses.org/browse/package/5808.html

-- How To Blog: http://is.gd/5b3Xk

-- Host: localhost
-- Generation Time: Jan 16, 2013 at 20:52 
-- 
-- MySQL version: 5.5.27
-- PHP Version: 5.4.7
-- 
-- 
-- Database: `yiivisit`
-- 
-- 
--  Table structure for table `access_rules`
-- 

/*!40000 DROP DATABASE IF EXISTS `'.yiivisit.'`*/; 

CREATE DATABASE `'.yiivisit.'`; 

USE `'.yiivisit.'`; 

CREATE TABLE `access_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `action_id` int(11) NOT NULL,
  `can_access` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_access_rules_profile1` (`profile_id`),
  KEY `fk_access_rules_sections1` (`section_id`),
  KEY `fk_access_rules_actions1` (`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


-- Dumping data for table `access_rules`

-- 
--  Table structure for table `actions`
-- 

/*!40000 DROP DATABASE IF EXISTS `'.yiivisit.'`*/; 

CREATE DATABASE `'.yiivisit.'`; 

USE `'.yiivisit.'`; 

CREATE TABLE `actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


-- Dumping data for table `actions`

INSERT INTO actions VALUES ('1', 'index');
INSERT INTO actions VALUES ('2', 'view');
INSERT INTO actions VALUES ('5', 'create');
INSERT INTO actions VALUES ('6', 'update');
INSERT INTO actions VALUES ('7', 'admin');
INSERT INTO actions VALUES ('8', 'delete');
INSERT INTO actions VALUES ('9', 'checkProduct');
INSERT INTO actions VALUES ('10', 'report');
-- 
--  Table structure for table `cantidad_envio`
-- 

/*!40000 DROP DATABASE IF EXISTS `'.yiivisit.'`*/; 

CREATE DATABASE `'.yiivisit.'`; 

USE `'.yiivisit.'`; 

CREATE TABLE `cantidad_envio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `texto` varchar(65) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


-- Dumping data for table `cantidad_envio`

INSERT INTO cantidad_envio VALUES ('1', 'N/A');
-- 
--  Table structure for table `cliente`
-- 

/*!40000 DROP DATABASE IF EXISTS `'.yiivisit.'`*/; 

CREATE DATABASE `'.yiivisit.'`; 

USE `'.yiivisit.'`; 

CREATE TABLE `cliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(95) COLLATE utf8_spanish_ci NOT NULL,
  `poblacion` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `persona_contacto` varchar(85) COLLATE utf8_spanish_ci NOT NULL,
  `id_competencia` int(11) NOT NULL,
  `id_tipo_envio` int(11) NOT NULL,
  `id_volumen_envio` int(11) NOT NULL,
  `id_cantidad_envio` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_competencia` (`id_competencia`),
  KEY `id_tipo_envio` (`id_tipo_envio`),
  KEY `id_volumen_envio` (`id_volumen_envio`),
  KEY `id_cantidad_evnio` (`id_cantidad_envio`),
  KEY `id_cantidad_envio` (`id_cantidad_envio`),
  CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`id_competencia`) REFERENCES `competencia` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cliente_ibfk_2` FOREIGN KEY (`id_tipo_envio`) REFERENCES `tipo_envio` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cliente_ibfk_4` FOREIGN KEY (`id_volumen_envio`) REFERENCES `volumen_envio` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cliente_ibfk_5` FOREIGN KEY (`id_cantidad_envio`) REFERENCES `cantidad_envio` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


-- Dumping data for table `cliente`

INSERT INTO cliente VALUES ('1', 'Prueba', '', '', '1', '1', '1', '1');
INSERT INTO cliente VALUES ('2', 'Prueba34234', 'prueba', '', '1', '1', '1', '1');
INSERT INTO cliente VALUES ('3', 'Cliente de', '', '', '1', '1', '1', '1');
INSERT INTO cliente VALUES ('4', 'Prueba2', 'MIcasa', 'Alguien', '2', '1', '1', '1');
-- 
--  Table structure for table `competencia`
-- 

/*!40000 DROP DATABASE IF EXISTS `'.yiivisit.'`*/; 

CREATE DATABASE `'.yiivisit.'`; 

USE `'.yiivisit.'`; 

CREATE TABLE `competencia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `texto` varchar(95) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


-- Dumping data for table `competencia`

INSERT INTO competencia VALUES ('1', 'N/A');
INSERT INTO competencia VALUES ('2', 'Prueba');
-- 
--  Table structure for table `profile`
-- 

/*!40000 DROP DATABASE IF EXISTS `'.yiivisit.'`*/; 

CREATE DATABASE `'.yiivisit.'`; 

USE `'.yiivisit.'`; 

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


-- Dumping data for table `profile`

INSERT INTO profile VALUES ('1', 'SinPerfil');
-- 
--  Table structure for table `sections`
-- 

/*!40000 DROP DATABASE IF EXISTS `'.yiivisit.'`*/; 

CREATE DATABASE `'.yiivisit.'`; 

USE `'.yiivisit.'`; 

CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `MenuUrl` varchar(75) COLLATE utf8_spanish_ci NOT NULL,
  `MenuName` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `MenuOrder` int(11) NOT NULL,
  `MenuSubSections` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `ParentId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


-- Dumping data for table `sections`

-- 
--  Table structure for table `tipo_envio`
-- 

/*!40000 DROP DATABASE IF EXISTS `'.yiivisit.'`*/; 

CREATE DATABASE `'.yiivisit.'`; 

USE `'.yiivisit.'`; 

CREATE TABLE `tipo_envio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `texto` varchar(65) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


-- Dumping data for table `tipo_envio`

INSERT INTO tipo_envio VALUES ('1', 'N/A');
-- 
--  Table structure for table `usuarios`
-- 

/*!40000 DROP DATABASE IF EXISTS `'.yiivisit.'`*/; 

CREATE DATABASE `'.yiivisit.'`; 

USE `'.yiivisit.'`; 

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(65) CHARACTER SET latin1 NOT NULL,
  `pass` varchar(65) CHARACTER SET latin1 NOT NULL,
  `profile_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `profile_id` (`profile_id`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish_ci;


-- Dumping data for table `usuarios`

INSERT INTO usuarios VALUES ('1', 'admin', 'admin', '1');
INSERT INTO usuarios VALUES ('2', 'juan', '123', '1');
-- 
--  Table structure for table `visita`
-- 

/*!40000 DROP DATABASE IF EXISTS `'.yiivisit.'`*/; 

CREATE DATABASE `'.yiivisit.'`; 

USE `'.yiivisit.'`; 

CREATE TABLE `visita` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `num_tarifa` int(11) NOT NULL,
  `tarifa_personalizada` tinyint(1) NOT NULL,
  `tarifa_aceptada` tinyint(1) NOT NULL,
  `fecha_planificada` varchar(8) CHARACTER SET latin1 NOT NULL,
  `fecha_visita` varchar(8) COLLATE utf8_spanish_ci NOT NULL,
  `comentarios` text CHARACTER SET latin1,
  `visitado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `visita_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


-- Dumping data for table `visita`

INSERT INTO visita VALUES ('2', '3', '123', '0', '1', '20110915', '', 'aaa', '0');
INSERT INTO visita VALUES ('3', '1', '1', '1', '1', '20111001', '', '', '0');
-- 
--  Table structure for table `volumen_envio`
-- 

/*!40000 DROP DATABASE IF EXISTS `'.yiivisit.'`*/; 

CREATE DATABASE `'.yiivisit.'`; 

USE `'.yiivisit.'`; 

CREATE TABLE `volumen_envio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `texto` varchar(65) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


-- Dumping data for table `volumen_envio`

INSERT INTO volumen_envio VALUES ('1', 'N/A');
