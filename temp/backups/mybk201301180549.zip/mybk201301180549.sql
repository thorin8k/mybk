-- Myeskuel Database Dump
-- version 1.01b
-- Host: localhost
-- Generation Time: Jan 18, 2013 at 17:49 
-- 
-- MySQL version: 5.5.28-0ubuntu0.12.10.2
-- PHP Version: 5.4.6-1ubuntu1.1
-- 
-- 
-- Database: `mybk`
-- 
-- 
--  Table structure for table `backup_work`
-- 

/*!40000 DROP DATABASE IF EXISTS `mybk`*/; 

CREATE DATABASE `mybk`; 

USE `mybk`; 

CREATE TABLE `backup_work` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `desc` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  `date_created` varchar(12) COLLATE utf8_spanish_ci NOT NULL,
  `afected_dbs` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


-- Dumping data for table `backup_work`

INSERT INTO backup_work VALUES ('1', 'test', '18/01/2013', '1', '0');
-- 
--  Table structure for table `config`
-- 


CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_cfg` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `value` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


-- Dumping data for table `config`

INSERT INTO config VALUES ('1', 'dropState', '3');
INSERT INTO config VALUES ('2', 'dropToken', '1gofcactv4k4ph5');
INSERT INTO config VALUES ('3', 'dropTokenSec', 'sivrvbjg95cm0co');
