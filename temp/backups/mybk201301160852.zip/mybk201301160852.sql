-- Myeskuel Database Dump
-- version 1.01b
-- Developed: Anish Karim C
-- Credits: http://www.phpclasses.org

-- Class Page: http://www.phpclasses.org/browse/package/5808.html

-- How To Blog: http://is.gd/5b3Xk

-- Host: localhost
-- Generation Time: Jan 16, 2013 at 20:52 
-- 
-- MySQL version: 5.5.27
-- PHP Version: 5.4.7
-- 
-- 
-- Database: `mybk`
-- 
-- 
--  Table structure for table `config`
-- 

/*!40000 DROP DATABASE IF EXISTS `'.mybk.'`*/; 

CREATE DATABASE `'.mybk.'`; 

USE `'.mybk.'`; 

CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_cfg` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `value` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


-- Dumping data for table `config`

INSERT INTO config VALUES ('23', 'dropToken', 'kj05al5k77s2pxm');
INSERT INTO config VALUES ('22', 'dropToken', 'm09dx0l18cny85l');
INSERT INTO config VALUES ('21', 'dropTokenSec', 'ani1sxprjl6oosz');
INSERT INTO config VALUES ('20', 'dropToken', '6rymu9bfhewc1pv');
